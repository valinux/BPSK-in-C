#ifndef REED_SOLOMON_H
#define REED_SOLOMON_H

#include <stdint.h>

// Reed-Solomon parameters
#define RS_SYMSIZE 8       // Symbol size in bits
#define RS_GFPOLY 0x11D    // Primitive polynomial for GF(256)
#define RS_FCR 0           // First consecutive root (usually 0 or 1)
#define RS_PRIM 1          // Primitive element to generate roots
#define RS_NROOTS 32       // Number of parity symbols (2 * max correctable symbols)
#define RS_NN ((1 << RS_SYMSIZE) - 1) // 255 for GF(256)
#define RS_KK (RS_NN - RS_NROOTS)     // Number of data symbols (223)

void reed_solomon_encode(uint8_t *data, uint8_t *parity);
int reed_solomon_decode(uint8_t *data);

#endif // REED_SOLOMON_H

