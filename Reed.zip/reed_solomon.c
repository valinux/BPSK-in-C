#include "reed_solomon.h"
#include <fec.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static void *rs_handler = NULL;

void reed_solomon_init() {
    if (rs_handler == NULL) {
        rs_handler = init_rs_char(RS_SYMSIZE, RS_GFPOLY, RS_FCR, RS_PRIM, RS_NROOTS, 0);
        if (rs_handler == NULL) {
            fprintf(stderr, "Failed to initialize Reed-Solomon codec\n");
            exit(EXIT_FAILURE);
        }
    }
}

void reed_solomon_encode(uint8_t *data, uint8_t *parity) {
    reed_solomon_init();
    encode_rs_char(rs_handler, data, parity);
}

int reed_solomon_decode(uint8_t *data) {
    reed_solomon_init();
    int num_errors = decode_rs_char(rs_handler, data, NULL, 0);
    return num_errors; // Returns number of corrected symbols, or -1 if uncorrectable
}

