#include "bpsk_modem.h"
#include <string.h>
#include <getopt.h>

void text_to_binary(const char* input_file, uint8_t** bits, size_t* num_bits) {
    FILE* file = fopen(input_file, "rb");
    if (!file) {
        perror("Failed to open input file");
        exit(EXIT_FAILURE);
    }

    // Get file size
    if (fseek(file, 0, SEEK_END) != 0) {
        perror("Failed to seek input file");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    long file_size_long = ftell(file);
    if (file_size_long == -1L) {
        perror("Failed to tell input file size");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    rewind(file);

    if (file_size_long == 0) {
        fprintf(stderr, "Input file is empty\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    if (file_size_long > UINT32_MAX) {
        fprintf(stderr, "Input file is too large\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    uint32_t original_file_size = (uint32_t)file_size_long;
    printf("Original file size: %u bytes\n", original_file_size);

    // Read file data
    uint8_t *data = (uint8_t *)malloc(original_file_size);
    if (!data) {
        fprintf(stderr, "Failed to allocate memory for input data\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    if (fread(data, 1, original_file_size, file) != original_file_size) {
        perror("Failed to read input file");
        free(data);
        fclose(file);
        exit(EXIT_FAILURE);
    }
    fclose(file);

    // Increase data size by 4 bytes to include the file size
    uint32_t total_data_size = original_file_size + 4;
    uint8_t *data_with_size = (uint8_t *)malloc(total_data_size);
    if (!data_with_size) {
        fprintf(stderr, "Failed to allocate memory for data with size\n");
        free(data);
        exit(EXIT_FAILURE);
    }

    // Write file size into data_with_size (big-endian)
    data_with_size[0] = (original_file_size >> 24) & 0xFF;
    data_with_size[1] = (original_file_size >> 16) & 0xFF;
    data_with_size[2] = (original_file_size >> 8) & 0xFF;
    data_with_size[3] = original_file_size & 0xFF;

    // Copy file data into data_with_size
    memcpy(data_with_size + 4, data, original_file_size);

    // Update file_size to total_data_size
    uint32_t file_size = total_data_size;

    // Initialize Reed-Solomon encoder
    void *rs_encoder = init_rs_char(RS_SYMSIZE, RS_GFPOLY, RS_FCR, RS_PRIM, RS_NROOTS, 0);
    if (!rs_encoder) {
        fprintf(stderr, "Failed to initialize Reed-Solomon encoder\n");
        free(data);
        free(data_with_size);
        exit(EXIT_FAILURE);
    }

    // Calculate number of blocks
    size_t num_blocks = (file_size + RS_KK - 1) / RS_KK;

    // Calculate the total number of valid symbols (data + parity), excluding padding zeros
    size_t valid_symbols = 0;

    // Allocate memory for encoded data (maximum possible size)
    uint8_t *encoded_data = (uint8_t *)malloc(num_blocks * RS_NN);
    if (!encoded_data) {
        fprintf(stderr, "Failed to allocate memory for encoded data\n");
        free(data);
        free(data_with_size);
        free_rs_char(rs_encoder);
        exit(EXIT_FAILURE);
    }

    // Reed-Solomon encoding
    for (size_t i = 0; i < num_blocks; i++) {
        size_t offset = i * RS_KK;
        size_t data_len = (file_size - offset >= RS_KK) ? RS_KK : file_size - offset;
        uint8_t block[RS_NN];
        memset(block, 0, RS_NN);
        memcpy(block, data_with_size + offset, data_len);

        // Encode parity symbols
        encode_rs_char(rs_encoder, block, block + RS_KK);

        // Number of symbols in this block (data_len + parity symbols)
        size_t symbols_in_block = data_len + RS_NROOTS;

        // Copy the data and parity symbols to encoded_data
        memcpy(encoded_data + valid_symbols, block, symbols_in_block);
        valid_symbols += symbols_in_block;
    }

    // Convert encoded data to bits (including preamble)
    *num_bits = valid_symbols * 8 + 8; // +8 for preamble
    *bits = (uint8_t*)calloc(*num_bits, sizeof(uint8_t));
    if (!*bits) {
        fprintf(stderr, "Failed to allocate memory for bits\n");
        free(data);
        free(data_with_size);
        free(encoded_data);
        free_rs_char(rs_encoder);
        exit(EXIT_FAILURE);
    }

    // Add preamble
    uint8_t preamble = PREAMBLE_BYTE;
    for (int i = 7; i >= 0; i--) {
        (*bits)[7 - i] = (preamble >> i) & 1;
    }

    // Convert only valid encoded data to bits
    size_t bit_index = 8;
    for (size_t i = 0; i < valid_symbols; i++) {
        uint8_t byte = encoded_data[i];
        for (int j = 7; j >= 0; j--) {
            (*bits)[bit_index++] = (byte >> j) & 1;
        }
    }

    printf("Total number of bits (including preamble): %zu\n", *num_bits);

    free(data);
    free(data_with_size);
    free(encoded_data);
    free_rs_char(rs_encoder);
}

void generate_bpsk_signal(const uint8_t* input_bits, size_t num_bits, int16_t** signal, size_t* signal_length, int fs, int baud, int f0) {
    size_t samples_per_bit = fs / baud;
    *signal_length = num_bits * samples_per_bit;
    *signal = (int16_t*)malloc(*signal_length * sizeof(int16_t));
    if (!*signal) {
        fprintf(stderr, "Failed to allocate memory for signal\n");
        exit(EXIT_FAILURE);
    }

    printf("Signal length to generate: %zu samples\n", *signal_length);

    for (size_t i = 0; i < num_bits; i++) {
        double phase = input_bits[i] ? 0.0 : M_PI;
        for (size_t j = 0; j < samples_per_bit; j++) {
            double t = (double)(i * samples_per_bit + j) / fs;
            double sample = sin(2.0 * M_PI * f0 * t + phase);
            (*signal)[i * samples_per_bit + j] = (int16_t)(sample * (INT16_MAX * 0.9)); // Scale down to prevent clipping
        }
    }
}

void write_wav_file(const char* output_file, const int16_t* signal, size_t signal_length, int fs) {
    FILE* file = fopen(output_file, "wb");
    if (!file) {
        perror("Failed to open output file");
        exit(EXIT_FAILURE);
    }

    WavHeader header;
    memset(&header, 0, sizeof(WavHeader));
    memcpy(header.chunk_id, "RIFF", 4);
    memcpy(header.format, "WAVE", 4);
    memcpy(header.subchunk1_id, "fmt ", 4);
    memcpy(header.subchunk2_id, "data", 4);

    header.subchunk1_size = 16;
    header.audio_format = 1;
    header.num_channels = 1;
    header.sample_rate = fs;
    header.bits_per_sample = 16;
    header.byte_rate = fs * header.num_channels * header.bits_per_sample / 8;
    header.block_align = header.num_channels * header.bits_per_sample / 8;
    header.subchunk2_size = (uint32_t)(signal_length * header.block_align);
    header.chunk_size = 36 + header.subchunk2_size;

    if (fwrite(&header, sizeof(WavHeader), 1, file) != 1) {
        perror("Failed to write WAV header");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    size_t written_samples = fwrite(signal, sizeof(int16_t), signal_length, file);
    if (written_samples != signal_length) {
        perror("Failed to write WAV data");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    fclose(file);
}

void read_wav_file(const char* input_file, int* fs, int16_t** signal, size_t* signal_length) {
    FILE* file = fopen(input_file, "rb");
    if (!file) {
        perror("Failed to open input WAV file");
        exit(EXIT_FAILURE);
    }

    WavHeader header;
    if (fread(&header, sizeof(WavHeader), 1, file) != 1) {
        perror("Failed to read WAV header");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Validate WAV file format
    if (strncmp(header.chunk_id, "RIFF", 4) != 0 || strncmp(header.format, "WAVE", 4) != 0) {
        fprintf(stderr, "Unsupported WAV file format\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    *fs = header.sample_rate;
    *signal_length = header.subchunk2_size / sizeof(int16_t);

    if (*signal_length == 0) {
        fprintf(stderr, "WAV file contains no data\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    *signal = (int16_t*)malloc(*signal_length * sizeof(int16_t));
    if (!*signal) {
        fprintf(stderr, "Failed to allocate memory for signal\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    if (fread(*signal, sizeof(int16_t), *signal_length, file) != *signal_length) {
        perror("Failed to read WAV data");
        free(*signal);
        fclose(file);
        exit(EXIT_FAILURE);
    }

    fclose(file);
}

void demodulate_bpsk(const int16_t* signal, int fs, int f0, int baud, size_t signal_length, uint8_t** demodulated_bits, size_t* bit_length) {
    size_t samples_per_bit = fs / baud;
    *bit_length = signal_length / samples_per_bit;
    *demodulated_bits = (uint8_t*)calloc(*bit_length, sizeof(uint8_t));
    if (!*demodulated_bits) {
        fprintf(stderr, "Failed to allocate memory for demodulated bits\n");
        exit(EXIT_FAILURE);
    }

    // Demodulate the signal
    for (size_t i = 0; i < *bit_length; i++) {
        double sum = 0.0;
        for (size_t j = 0; j < samples_per_bit; j++) {
            double t = (double)(i * samples_per_bit + j) / fs;
            double reference = sin(2.0 * M_PI * f0 * t);
            sum += signal[i * samples_per_bit + j] * reference;
        }

        // Determine bit value based on the sign of the sum
        (*demodulated_bits)[i] = (sum > 0.0) ? 1 : 0;
    }

    // Print first 32 demodulated bits for debugging
    printf("First 32 demodulated bits:\n");
    for (size_t i = 0; i < 32 && i < *bit_length; i++) {
        printf("%d", (*demodulated_bits)[i]);
    }
    printf("\n");

    // Synchronization using preamble detection
    size_t preamble_index = 0;
    bool preamble_found = false;

    for (size_t i = 0; i <= *bit_length - 8; i++) {
        uint8_t preamble = 0;
        for (int k = 0; k < 8; k++) {
            preamble |= (*demodulated_bits)[i + k] << (7 - k);
        }
        if (preamble == PREAMBLE_BYTE) {
            preamble_index = i + 8;
            preamble_found = true;
            printf("Preamble found at bit index %zu\n", i);
            break;
        }
    }

    if (!preamble_found) {
        fprintf(stderr, "Preamble not found. Synchronization failed.\n");
        free(*demodulated_bits);
        exit(EXIT_FAILURE);
    }

    // Shift bits to exclude preamble
    size_t data_bits = *bit_length - preamble_index;
    memmove(*demodulated_bits, *demodulated_bits + preamble_index, data_bits * sizeof(uint8_t));
    *bit_length = data_bits;

    printf("Bit length after removing preamble: %zu\n", *bit_length);
}

void binary_to_text(const uint8_t* bits, size_t bit_length, const char* output_file) {
    // Initialize Reed-Solomon decoder
    void *rs_decoder = init_rs_char(RS_SYMSIZE, RS_GFPOLY, RS_FCR, RS_PRIM, RS_NROOTS, 0);
    if (!rs_decoder) {
        fprintf(stderr, "Failed to initialize Reed-Solomon decoder\n");
        exit(EXIT_FAILURE);
    }

    // Convert bits to bytes
    size_t total_symbols = bit_length / 8;
    uint8_t *received_data = (uint8_t *)malloc(total_symbols);
    if (!received_data) {
        fprintf(stderr, "Failed to allocate memory for received data\n");
        free_rs_char(rs_decoder);
        exit(EXIT_FAILURE);
    }

    size_t bit_index = 0;
    for (size_t i = 0; i < total_symbols; i++) {
        uint8_t byte = 0;
        for (int j = 7; j >= 0; j--) {
            byte |= bits[bit_index++] << j;
        }
        received_data[i] = byte;
    }

    // Reed-Solomon decoding
    size_t processed_symbols = 0;
    size_t decoded_index = 0;
    uint8_t *decoded_data = (uint8_t *)malloc(total_symbols); // Maximum possible size
    if (!decoded_data) {
        fprintf(stderr, "Failed to allocate memory for decoded data\n");
        free(received_data);
        free_rs_char(rs_decoder);
        exit(EXIT_FAILURE);
    }

    while (processed_symbols < total_symbols) {
        size_t symbols_left = total_symbols - processed_symbols;
        size_t symbols_in_block = (symbols_left >= RS_NN) ? RS_NN : symbols_left;

        // Prepare the block
        uint8_t block[RS_NN];
        memset(block, 0, RS_NN);
        memcpy(block, received_data + processed_symbols, symbols_in_block);

        // Pad the block if it's shorter than RS_NN
        if (symbols_in_block < RS_NN) {
            memset(block + symbols_in_block, 0, RS_NN - symbols_in_block);
        }

        int ret = decode_rs_char(rs_decoder, block, NULL, 0);
        if (ret >= 0) {
            printf("Decoded block at position %zu with %d corrections\n", processed_symbols, ret);
        } else {
            fprintf(stderr, "Unrecoverable errors in block at position %zu\n", processed_symbols);
            // Proceeding with the data as is
        }

        // Determine number of data symbols in this block
        size_t data_symbols = (symbols_in_block >= RS_NROOTS) ? symbols_in_block - RS_NROOTS : 0;

        memcpy(decoded_data + decoded_index, block, data_symbols);
        decoded_index += data_symbols;
        processed_symbols += symbols_in_block;
    }

    // After Reed-Solomon decoding, we have decoded_data of size decoded_index
    // Extract the original file size from the first 4 bytes
    if (decoded_index < 4) {
        fprintf(stderr, "Decoded data too short to contain file size\n");
        free(received_data);
        free(decoded_data);
        free_rs_char(rs_decoder);
        exit(EXIT_FAILURE);
    }

    uint32_t original_file_size = (decoded_data[0] << 24) | (decoded_data[1] << 16) |
                                  (decoded_data[2] << 8) | decoded_data[3];

    // Check that the original file size does not exceed the decoded data length
    if (original_file_size > decoded_index - 4) {
        fprintf(stderr, "Invalid original file size: %u\n", original_file_size);
        free(received_data);
        free(decoded_data);
        free_rs_char(rs_decoder);
        exit(EXIT_FAILURE);
    }

    // Write only the actual data to the output file
    FILE* file = fopen(output_file, "wb");
    if (!file) {
        perror("Failed to open output text file");
        free(received_data);
        free(decoded_data);
        free_rs_char(rs_decoder);
        exit(EXIT_FAILURE);
    }

    fwrite(decoded_data + 4, 1, original_file_size, file);

    fclose(file);
    free(received_data);
    free(decoded_data);
    free_rs_char(rs_decoder);
}

void parse_arguments(int argc, char* argv[], bool* is_tx, int* fs, int* baud, int* f0, char** input_file, char** output_file) {
    *is_tx = false;
    *fs = DEFAULT_FS;
    *baud = DEFAULT_BAUD;
    *f0 = DEFAULT_F0;
    *input_file = NULL;
    *output_file = NULL;

    static struct option long_options[] = {
        {"tx", no_argument, 0, 't'},
        {"rx", no_argument, 0, 'r'},
        {"fs", required_argument, 0, 's'},
        {"baud", required_argument, 0, 'b'},
        {"f0", required_argument, 0, 'f'},
        {"input", required_argument, 0, 'i'},
        {"output", required_argument, 0, 'o'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int opt;
    int option_index = 0;
    bool mode_set = false;

    // Corrected options string
    while ((opt = getopt_long(argc, argv, "trh:s:b:f:i:o:", long_options, &option_index)) != -1) {
        switch (opt) {
            case 't':
                *is_tx = true;
                mode_set = true;
                break;
            case 'r':
                *is_tx = false;
                mode_set = true;
                break;
            case 'h':
                // Display help message
                fprintf(stderr, "Usage: %s (--tx | --rx) -i <input_file> -o <output_file> [options]\n", argv[0]);
                fprintf(stderr, "Options:\n");
                fprintf(stderr, "  --tx                Transmit mode\n");
                fprintf(stderr, "  --rx                Receive mode\n");
                fprintf(stderr, "  -s, --fs <rate>     Sampling rate (default %d)\n", DEFAULT_FS);
                fprintf(stderr, "  -b, --baud <rate>   Baud rate (default %d)\n", DEFAULT_BAUD);
                fprintf(stderr, "  -f, --f0 <freq>     Carrier frequency (default %d)\n", DEFAULT_F0);
                fprintf(stderr, "  -i, --input <file>  Input file\n");
                fprintf(stderr, "  -o, --output <file> Output file\n");
                exit(EXIT_SUCCESS);
                break;
            case 's':
                *fs = atoi(optarg);
                if (*fs <= 0) {
                    fprintf(stderr, "Invalid sampling rate\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'b':
                *baud = atoi(optarg);
                if (*baud <= 0) {
                    fprintf(stderr, "Invalid baud rate\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'f':
                *f0 = atoi(optarg);
                if (*f0 <= 0) {
                    fprintf(stderr, "Invalid carrier frequency\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'i':
                *input_file = optarg;
                break;
            case 'o':
                *output_file = optarg;
                break;
            default:
                fprintf(stderr, "Unknown option\n");
                exit(EXIT_FAILURE);
        }
    }

    if (!mode_set || !*input_file || !*output_file) {
        fprintf(stderr, "Missing required arguments. Use --help for usage information.\n");
        exit(EXIT_FAILURE);
    }
}

