#include "bpsk_modem.h"

int main(int argc, char* argv[]) {
    int fs;
    int baud;
    int f0;
    char* input_file = NULL;
    char* output_file = NULL;
    bool is_tx = false;

    parse_arguments(argc, argv, &is_tx, &fs, &baud, &f0, &input_file, &output_file);

    printf("Mode: %s\n", is_tx ? "Transmit" : "Receive");
    printf("Sampling Rate (fs): %d Hz\n", fs);
    printf("Baud Rate: %d symbols/sec\n", baud);
    printf("Carrier Frequency (f0): %d Hz\n", f0);
    printf("Input File: %s\n", input_file);
    printf("Output File: %s\n", output_file);

    if (is_tx) {
        // Transmitter mode
        uint8_t* input_bits = NULL;
        size_t num_bits = 0;

        printf("Converting text to binary with Reed-Solomon encoding...\n");
        text_to_binary(input_file, &input_bits, &num_bits);
        printf("Number of bits (including preamble): %lu\n", (unsigned long)num_bits);

        int16_t* bpsk_signal = NULL;
        size_t signal_length = 0;

        printf("Generating BPSK signal...\n");
        generate_bpsk_signal(input_bits, num_bits, &bpsk_signal, &signal_length, fs, baud, f0);
        printf("Signal length: %lu samples\n", (unsigned long)signal_length);

        printf("Writing signal to WAV file...\n");
        write_wav_file(output_file, bpsk_signal, signal_length, fs);
        printf("WAV file saved: %s\n", output_file);

        free(input_bits);
        free(bpsk_signal);
    } else {
        // Receiver mode
        int16_t* signal = NULL;
        size_t signal_length = 0;

        printf("Reading WAV file...\n");
        read_wav_file(input_file, &fs, &signal, &signal_length);
        printf("Signal length: %lu samples\n", (unsigned long)signal_length);
        printf("Sampling Rate from WAV file: %d Hz\n", fs);

        uint8_t* demodulated_bits = NULL;
        size_t bit_length = 0;

        printf("Demodulating BPSK signal...\n");
        demodulate_bpsk(signal, fs, f0, baud, signal_length, &demodulated_bits, &bit_length);
        printf("Demodulated bits: %lu\n", (unsigned long)bit_length);

        printf("Converting binary to text with Reed-Solomon decoding...\n");
        binary_to_text(demodulated_bits, bit_length, output_file);
        printf("Recovered text saved to: %s\n", output_file);

        free(signal);
        free(demodulated_bits);
    }

    return 0;
}

