#ifndef BPSK_MODEM_H
#define BPSK_MODEM_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Constants
#define DEFAULT_FS 8000
#define DEFAULT_BAUD 300
#define DEFAULT_F0 1500
#define PREAMBLE_BYTE 0xAA // 10101010 in binary

// WAV file header structure
#pragma pack(push, 1)
typedef struct {
    char chunk_id[4];
    uint32_t chunk_size;
    char format[4];
    char subchunk1_id[4];
    uint32_t subchunk1_size;
    uint16_t audio_format;
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;
    char subchunk2_id[4];
    uint32_t subchunk2_size;
} WavHeader;
#pragma pack(pop)

// Function Prototypes
void text_to_binary(const char* input_file, uint8_t** bits, size_t* num_bits);
void generate_bpsk_signal(const uint8_t* input_bits, size_t num_bits, int16_t** signal, size_t* signal_length, int fs, int baud, int f0);
void write_wav_file(const char* output_file, const int16_t* signal, size_t signal_length, int fs);
void read_wav_file(const char* input_file, int* fs, int16_t** signal, size_t* signal_length);
void demodulate_bpsk(const int16_t* signal, int fs, int f0, int baud, size_t signal_length, uint8_t** demodulated_bits, size_t* bit_length);
void binary_to_text(const uint8_t* bits, size_t bit_length, const char* output_file);
void parse_arguments(int argc, char* argv[], bool* is_tx, int* fs, int* baud, int* f0, char** input_file, char** output_file);

#endif // BPSK_MODEM_H

