#include "bpsk_modem.h"
#include <string.h>
#include <math.h>
#include <getopt.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void text_to_binary(const char* input_file, uint8_t** bits, size_t* num_bits) {
    FILE* file = fopen(input_file, "rb");
    if (!file) {
        perror("Failed to open input file");
        exit(EXIT_FAILURE);
    }

    // Get file size
    if (fseek(file, 0, SEEK_END) != 0) {
        perror("Failed to seek input file");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    long file_size = ftell(file);
    if (file_size == -1L) {
        perror("Failed to tell input file size");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    rewind(file);

    // Allocate memory for bits (including preamble)
    size_t total_bits = (file_size + 1) * 8; // +1 for preamble
    *bits = (uint8_t*)calloc(total_bits, sizeof(uint8_t));
    if (!*bits) {
        fprintf(stderr, "Failed to allocate memory for bits\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Add preamble
    uint8_t preamble = PREAMBLE_BYTE;
    for (int i = 7; i >= 0; i--) {
        (*bits)[7 - i] = (preamble >> i) & 1;
    }

    // Read file and convert to bits
    size_t bit_index = 8;
    uint8_t byte;
    while (fread(&byte, sizeof(uint8_t), 1, file) == 1) {
        for (int i = 7; i >= 0; i--) {
            (*bits)[bit_index++] = (byte >> i) & 1;
        }
    }

    *num_bits = total_bits;

    fclose(file);
}

void generate_bpsk_signal(const uint8_t* input_bits, size_t num_bits, int16_t** signal, size_t* signal_length, int fs, int baud, int f0) {
    size_t samples_per_bit = fs / baud;
    *signal_length = num_bits * samples_per_bit;
    *signal = (int16_t*)malloc(*signal_length * sizeof(int16_t));
    if (!*signal) {
        fprintf(stderr, "Failed to allocate memory for signal\n");
        exit(EXIT_FAILURE);
    }

    for (size_t i = 0; i < num_bits; i++) {
        double phase = input_bits[i] ? 0.0 : M_PI;
        for (size_t j = 0; j < samples_per_bit; j++) {
            double t = (double)(i * samples_per_bit + j) / fs;
            double sample = sin(2.0 * M_PI * f0 * t + phase);
            (*signal)[i * samples_per_bit + j] = (int16_t)(sample * (INT16_MAX * 0.9)); // Scale down to 90% to prevent clipping
        }
    }
}

void write_wav_file(const char* output_file, const int16_t* signal, size_t signal_length, int fs) {
    FILE* file = fopen(output_file, "wb");
    if (!file) {
        perror("Failed to open output file");
        exit(EXIT_FAILURE);
    }

    WavHeader header;
    memset(&header, 0, sizeof(WavHeader));
    memcpy(header.chunk_id, "RIFF", 4);
    memcpy(header.format, "WAVE", 4);
    memcpy(header.subchunk1_id, "fmt ", 4);
    memcpy(header.subchunk2_id, "data", 4);

    header.subchunk1_size = 16;
    header.audio_format = 1;
    header.num_channels = 1;
    header.sample_rate = fs;
    header.bits_per_sample = 16;
    header.byte_rate = fs * header.num_channels * header.bits_per_sample / 8;
    header.block_align = header.num_channels * header.bits_per_sample / 8;
    header.subchunk2_size = (uint32_t)(signal_length * header.block_align);
    header.chunk_size = 36 + header.subchunk2_size;

    if (fwrite(&header, sizeof(WavHeader), 1, file) != 1) {
        perror("Failed to write WAV header");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    if (fwrite(signal, sizeof(int16_t), signal_length, file) != signal_length) {
        perror("Failed to write WAV data");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    fclose(file);
}

void read_wav_file(const char* input_file, int* fs, int16_t** signal, size_t* signal_length) {
    FILE* file = fopen(input_file, "rb");
    if (!file) {
        perror("Failed to open input WAV file");
        exit(EXIT_FAILURE);
    }

    WavHeader header;
    if (fread(&header, sizeof(WavHeader), 1, file) != 1) {
        perror("Failed to read WAV header");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Validate WAV file format
    if (strncmp(header.chunk_id, "RIFF", 4) != 0 || strncmp(header.format, "WAVE", 4) != 0) {
        fprintf(stderr, "Unsupported WAV file format\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    *fs = header.sample_rate;
    *signal_length = header.subchunk2_size / sizeof(int16_t);
    *signal = (int16_t*)malloc(*signal_length * sizeof(int16_t));
    if (!*signal) {
        fprintf(stderr, "Failed to allocate memory for signal\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    if (fread(*signal, sizeof(int16_t), *signal_length, file) != *signal_length) {
        perror("Failed to read WAV data");
        free(*signal);
        fclose(file);
        exit(EXIT_FAILURE);
    }

    fclose(file);
}

void demodulate_bpsk(const int16_t* signal, int fs, int f0, int baud, size_t signal_length, uint8_t** demodulated_bits, size_t* bit_length) {
    size_t samples_per_bit = fs / baud;
    *bit_length = signal_length / samples_per_bit;
    *demodulated_bits = (uint8_t*)calloc(*bit_length, sizeof(uint8_t));
    if (!*demodulated_bits) {
        fprintf(stderr, "Failed to allocate memory for demodulated bits\n");
        exit(EXIT_FAILURE);
    }

    // Demodulate the signal
    for (size_t i = 0; i < *bit_length; i++) {
        double sum = 0.0;
        for (size_t j = 0; j < samples_per_bit; j++) {
            double t = (double)(i * samples_per_bit + j) / fs;
            double reference = sin(2.0 * M_PI * f0 * t);
            sum += signal[i * samples_per_bit + j] * reference;
        }

        // Determine bit value based on the sign of the sum
        (*demodulated_bits)[i] = (sum > 0.0) ? 1 : 0;
    }

    // Print first 32 demodulated bits for debugging
    printf("First 32 demodulated bits:\n");
    for (size_t i = 0; i < 32 && i < *bit_length; i++) {
        printf("%d", (*demodulated_bits)[i]);
    }
    printf("\n");

    // Synchronization using preamble detection
    size_t preamble_index = 0;
    bool preamble_found = false;

    for (size_t i = 0; i <= *bit_length - 8; i++) {
        uint8_t preamble = 0;
        for (int k = 0; k < 8; k++) {
            preamble |= (*demodulated_bits)[i + k] << (7 - k);
        }
        if (preamble == PREAMBLE_BYTE) {
            preamble_index = i + 8;
            preamble_found = true;
            printf("Preamble found at bit index %zu\n", i);
            break;
        }
    }

    if (!preamble_found) {
        fprintf(stderr, "Preamble not found. Synchronization failed.\n");
        free(*demodulated_bits);
        exit(EXIT_FAILURE);
    }

    // Shift bits to exclude preamble
    size_t data_bits = *bit_length - preamble_index;
    memmove(*demodulated_bits, *demodulated_bits + preamble_index, data_bits * sizeof(uint8_t));
    *bit_length = data_bits;

    printf("Bit length after removing preamble: %zu\n", *bit_length);
}

void binary_to_text(const uint8_t* bits, size_t bit_length, const char* output_file) {
    FILE* file = fopen(output_file, "wb");
    if (!file) {
        perror("Failed to open output text file");
        exit(EXIT_FAILURE);
    }

    size_t num_bytes = bit_length / 8;
    uint8_t* bytes = (uint8_t*)malloc(num_bytes * sizeof(uint8_t));
    if (!bytes) {
        fprintf(stderr, "Failed to allocate memory for bytes\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    for (size_t i = 0; i < num_bytes; i++) {
        uint8_t byte = 0;
        for (int j = 0; j < 8; j++) {
            byte |= bits[i * 8 + j] << (7 - j);
        }
        bytes[i] = byte;
    }

    // Print first 16 bytes for debugging
    printf("First 16 bytes of recovered data:\n");
    for (size_t i = 0; i < num_bytes && i < 16; i++) {
        printf("%02X ", bytes[i]);
    }
    printf("\n");

    if (fwrite(bytes, sizeof(uint8_t), num_bytes, file) != num_bytes) {
        perror("Failed to write to output text file");
        free(bytes);
        fclose(file);
        exit(EXIT_FAILURE);
    }

    free(bytes);
    fclose(file);
}

void parse_arguments(int argc, char* argv[], bool* is_tx, int* fs, int* baud, int* f0, char** input_file, char** output_file) {
    *is_tx = false;
    *fs = DEFAULT_FS;
    *baud = DEFAULT_BAUD;
    *f0 = DEFAULT_F0;
    *input_file = NULL;
    *output_file = NULL;

    static struct option long_options[] = {
        {"tx", no_argument, 0, 't'},
        {"rx", no_argument, 0, 'r'},
        {"fs", required_argument, 0, 's'},
        {"baud", required_argument, 0, 'b'},
        {"f0", required_argument, 0, 'f'},
        {"input", required_argument, 0, 'i'},
        {"output", required_argument, 0, 'o'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int opt;
    int option_index = 0;
    bool mode_set = false;

    while ((opt = getopt_long(argc, argv, "trhs:b:f:i:o:", long_options, &option_index)) != -1) {
        switch (opt) {
            case 't':
                *is_tx = true;
                mode_set = true;
                break;
            case 'r':
                *is_tx = false;
                mode_set = true;
                break;
            case 's':
                *fs = atoi(optarg);
                if (*fs <= 0) {
                    fprintf(stderr, "Invalid sampling rate\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'b':
                *baud = atoi(optarg);
                if (*baud <= 0) {
                    fprintf(stderr, "Invalid baud rate\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'f':
                *f0 = atoi(optarg);
                if (*f0 <= 0) {
                    fprintf(stderr, "Invalid carrier frequency\n");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'i':
                *input_file = optarg;
                break;
            case 'o':
                *output_file = optarg;
                break;
            case 'h':
            default:
                fprintf(stderr, "Usage: %s (--tx | --rx) -i <input_file> -o <output_file> [options]\n", argv[0]);
                fprintf(stderr, "Options:\n");
                fprintf(stderr, "  --tx                Transmit mode\n");
                fprintf(stderr, "  --rx                Receive mode\n");
                fprintf(stderr, "  -s, --fs <rate>     Sampling rate (default %d)\n", DEFAULT_FS);
                fprintf(stderr, "  -b, --baud <rate>   Baud rate (default %d)\n", DEFAULT_BAUD);
                fprintf(stderr, "  -f, --f0 <freq>     Carrier frequency (default %d)\n", DEFAULT_F0);
                fprintf(stderr, "  -i, --input <file>  Input file\n");
                fprintf(stderr, "  -o, --output <file> Output file\n");
                exit(EXIT_FAILURE);
        }
    }

    if (!mode_set || !*input_file || !*output_file) {
        fprintf(stderr, "Missing required arguments. Use --help for usage information.\n");
        exit(EXIT_FAILURE);
    }
}

